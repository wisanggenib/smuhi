<?php

    $config = mysqli_connect('localhost','root','','db_smuhi2');

?>