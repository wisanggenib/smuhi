<section class="banner-area relative" id="home" style="height : 350px;">
	<div class="overlay overlay-bg"></div>
	<div class="container">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-uppercase text-white" align="right">
                Selamat Datang Alumni<br>
                SMA 1 Muhammadiyah Yogyakarta
                </h1>
            </div>
        </div>
	</div>
</section>

<section class="popular-course-area single-post-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="border-style : solid; height : 200px; margin-bottom: 100px; position: relative ; top : -50px;">
            
            </div>
        </div>

        <div class="row" style="position : relative;top : -100px;">           

            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 posts-list">
                <div class="row">
                    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-3">
                        <?php
                            $rating = 2.5;
                            for($i = 1 ; $i <= 5 ; $i++){
                                if($i <= $rating){
                                    ?>
                                        <i class="fa fa-star fa-2x" style="color: gold;" title="<?=$rating?>"></i>
                                    <?php
                                }
                                else{
                                    ?>
                                        <i class="fa fa-star fa-2x
                                        "></i>
                                    <?php
                                }
                                    
                            }

                        ?>
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2">
                        <a href="" style="color : gray;">
                            <i class="fa fa-share-alt fa-2x"> 29</i>
                        </a>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                        <a href="" style="color : gray;"><i class="fa fa-facebook fa-lg"></i></a>
                        <a href="" style="color : gray;"><i class="fa fa-instagram fa-lg" style="margin-left:15px;"></i></a>
                        <a href="" style="color : gray;"><i class="fa fa-whatsapp fa-lg" style="margin-left: 15px;"></i></a>
                        <a href="" style="color : gray;"><i class="fa fa-twitter fa-lg" style="margin-left: 15px;"></i></a>
                        <a href="" style="color : gray;"><i class="fa fa-envelope fa-lg" style="margin-left: 15px;"></i></a>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                                <input type="text" class="form-control" value="" style="position: relative ; top : -5px;" readonly>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                                <a href="" style="color : gray;"><i class="fa fa-link fa-lg" style="margin-right : 15px;"></i></a>
                                <a href="" style="color : gray;"><i class="fa fa-bookmark fa-lg"></i></a>
                            </div>
                        </div>
                    </div>

                    <hr size="15px" width="100%">
                </div>

                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <img src="img/full-01.jpg" alt="" width="100%">
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <h1>EMO T-Shirt</h1>
                        <p>Posted on <i>29-07-2018 14:52</i> </p>
                        <br>
                        <h1 style="color: blue">Rp 47.000</h1>
                        <div style="background : #DCDCDC; margin-top : 20px;">
                            <ul style="margin : 20px; font-size : 18px;">
                                <li>Lokasi : DKI Jakarta</li>
                                <li>Kondisi : Baru</li>
                                <li>SMS/WA : 081332739326</li>
                                <li>Website : <a href="">www.toko.co.id</a> </li>
                                <li>Line@ : @toko (pakai@)</li>
                                <li>Status : Tanyakan Stok</li>
                            </ul>
                            <ul style="margin : 20px; font-size: 18px;">
                                <li>Terjual : 0 Barang Telah Terjual</li>
                                <li>Dilihat : 561 Kali</li>
                                <li>Berat : 100 gram</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6 col-md-6" align="center">
                        <img src="img/full-01.jpg" alt="" width="20%">
                        <img src="img/full-02.jpg" alt="" width="20%">
                        <img src="img/full-03.jpg" alt="" width="20%">
                    </div>
                    <div class="col-lg-6 col-md-6" align="center">
                        <div style="background : #32CD32; width: 80%; height : 90px; border-radius : 5px;">
                            <a href="" style="color : white;">
                                <i class="fa fa-whatsapp fa-5x" style="margin: 10px;"> Beli</i>
                            </a>
                        </div>                                                
                    </div>
                </div>

                <div class="row" style="margin-top : 30px;">
                    <div class="col-lg-12 col-md-12">
                        <h1>Informasi Produk</h1>
                    </div>
                    <hr color="blue" width="25%" align="left">
                    <div class="col-lg-12 col-md-12">
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis maiores, culpa repellat labore, magnam placeat amet blanditiis est harum assumenda sint. Harum nemo, odio animi ipsum impedit dolores nesciunt incidunt. Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore atque aspernatur saepe id autem beatae qui voluptates nisi commodi, dignissimos esse quia optio eos aperiam quisquam, quidem fugit sit repudiandae. Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem facilis aliquid labore, asperiores, vitae delectus velit consectetur soluta maxime aperiam natus! Ab, ullam. Eaque pariatur non nulla ut recusandae amet. Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis eius, officiis, suscipit eveniet tempora soluta nam inventore nesciunt perspiciatis nemo, molestiae nisi sit possimus distinctio cupiditate hic expedita. Iusto, dolor!
                        </p>
                    </div>
                </div>
                          
            </div>
            

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 sidebar-widgets" >
                <div class="widget-wrap">                    

                    <div class="single-sidebar-widget popular-post-widget" style="position : relative;top : -40px;">
                        <h4 align="center">SELLER INFO</h4>
                        <hr size="15px;" color="blue" width="50%">
                        <div class="popular-post-list">
                            <div class="col-lg-4 col-md-4">
                                <img src="../img/112.jpg" alt="" width="100%" height = "70px;">
                            </div>
                            <div class="col-lg-8 col-md-8">
                                <h4>Bagus Sekali</h4>
                                <p>Join : <i>18-04-2013</i></p>
                                <i class="fa fa-map"></i> DKI Jakarta
                            </div>
                            <div class="row">
                                <div class="col-lg-6 col-md-6" align="left" style="margin-top : 20px;">
                                    <i class="fa fa-star fa-3x" style="color : gold; float : left ; margin-right : 10px;"></i> <p>Pedagang SUKSES</p>
                                </div>
                                <div class="col-lg-6 col-md-6" align="left" style="margin-top : 20px;">
                                    <i class="fa fa-star fa-3x" style="color : gold; float : left ; margin-right : 10px;"></i> <p>Pedagang SUKSES</p>
                                </div>
                            </div>
                            <div class="" align ="right">
                                <a href="index.php?page=lowongan_kerja">Lihat Selengkapnya <i class="fa fa-chevron-circle-right"></i></a>
                            </div>                            
                            
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height : 5px; background: yellow; margin-top : 15px; margin-bottom : 15px;"></div>   
                    </div>

                    <div class="single-sidebar-widget popular-post-widget">                        
                        <div class="popular-post-list" style="border-style: solid; height : 200px;"></div>
                    </div>

                    <div class="single-sidebar-widget popular-post-widget">
                        <h4 align="center">PRODUK LAIN DARI PENJUALAN</h4>
                        <hr size="15px;" color="blue" width="50%">
                        <div class="popular-post-list">

                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-4" align="center">
                                        <img src="img/img-02-hover.jpg" alt="" width="100%">
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">
                                        <h5>Wifi Action Camera</h5>
                                        <p>Rp 99.000</p>
                                        <a href="" class="btn btn-success">Beli</a>
                                    <hr size="15px;" color="#FFFF00">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-4" align="center">
                                        <img src="img/img-04-hover.jpg" alt="" width="100%">
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">
                                        <h5>Indor Security Camera</h5>
                                        <p>Rp 99.000</p>
                                        <a href="" class="btn btn-success">Beli</a>
                                    <hr size="15px;" color="#FFFF00">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-4" align="center">
                                        <img src="img/img-01-hover.jpg" alt="" width="100%">
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">
                                        <h5>Wirelless Gaming Controller</h5>
                                        <p>Rp 99.000</p>
                                        <a href="" class="btn btn-success">Beli</a>
                                    <hr size="15px;" color="#FFFF00">
                                    </div>
                                </div>
                            </div>

                            <div class="" align ="right">
                                <a href="index.php?page=lowongan_kerja">Lihat Selengkapnya <i class="fa fa-chevron-circle-right"></i></a>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="height : 5px; background: yellow; margin-top : 15px; margin-bottom : 15px;"></div>   
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>